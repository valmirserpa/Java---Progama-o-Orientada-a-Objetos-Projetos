
package MeuPrimeiroProjeto;


public class Main {

   
    public static void main(String[] args) {
       

        System.out.println("Hello, World!");
        System.out.println("Meu segundo comando!");
        System.out.println("Olá, mundo!");



    }
    
}
