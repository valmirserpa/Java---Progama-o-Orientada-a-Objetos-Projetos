package EstruturaEscolha;

public class Main {

    public static void main(String[] args) {

        int codigoProduto = 2;

        switch (codigoProduto) {

            case 1:
                break; // O BREAK É O PONTO DE PARADA DO CASO E TODO O CASO PRECISA TER UM BREAK;
            
            case 2:
                break;
            
            case 3:
                break;
            
            default: // CASO O CÓDIDO NÃO SEJA ATENDIDO POR NENHUM DOS CASOS, PODEMOS DEFINIR UM VALOR DEFAULT
        }

    }
}
