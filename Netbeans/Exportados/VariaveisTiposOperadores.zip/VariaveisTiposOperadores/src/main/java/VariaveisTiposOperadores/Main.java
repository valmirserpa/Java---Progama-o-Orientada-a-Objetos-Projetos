
package VariaveisTiposOperadores;


public class Main {

    
    public static void main(String[] args) {
 
        // TIPOS PRIMITIVOS DE VARIÁVEIS
        int idade=0;
        float data=5.0f;
        double mes=6.0d;
        char letra= 'A'; // SERVE PARA ARMAZENAR UMA LETRA
        byte placar;
        boolean estaCadastrado;
        
        // VARIÁVEIS NÃO PRIMITIVAS
        
        String nome = "Esse é o texto de uma variável String";
        
        //OPERADORES LÓGICOS
        
    /*  
        + 
        -
        /
        *
        %
        
      */          
        
    }
}
