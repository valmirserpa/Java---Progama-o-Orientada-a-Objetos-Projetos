
package ComandosLeituraGravacao;

import java.util.Scanner;

public class Main {

   
    public static void main(String[] args) {
       
        
        Scanner leitor = new Scanner(System.in);
        
        
        int idade = leitor.nextInt();
        float cotacaoDolar = leitor.nextFloat();
        double cotacaoEuro = leitor.nextDouble();
        String nome = leitor.nextLine(); //LER UMA LINHA INTEIRA
        String codigo =leitor.next(); // LER UMA PALAVRA
        
        
        System.out.println("O texto que será exbido no console!");
        
        
        
        
        
        
        
        
        
    }
    
}
