
package Aula06Encapsulamento;

public class Main {
public static void main(String[] args) {
        
    ControleRemoto c1 = new ControleRemoto();
    
    c1.ligar();
    c1.abrirMenu();
    c1.desligar();
    c1.maisVolume();
    c1.menosVolume();
 
    
    
    
    
    
    
    
    }
    
}
