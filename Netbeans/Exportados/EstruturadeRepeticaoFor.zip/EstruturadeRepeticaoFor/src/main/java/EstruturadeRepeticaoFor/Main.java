
package EstruturadeRepeticaoFor;

public class Main {

    public static void main(String[] args) {

       /*
       
       VAMOS UTILIZAR O FOR QUANDO SABEMOS A QUANTIDADE DE VEZES QUE A ESTRUTURA 
       DE REPETIÇÃO SERÁ EXECUTADA
        
       O FOR É DIVIDO EM 3 PARTES
        
       int i = 0; ---> REPRESENTA A VARIÁVEL DE CONTROLE, OU SEJA, ELA ARMAZENA
       QUANTAS VEZES A ESTRUTURA FOI EXECUTADA  TAMBÉM ARMARZENA 
       
       i <=10; ---> REPRESENTA A CONDIÇÃO DE EXECUÇÃO, OU SEJA, QUALA CONDIÇÃO 
       PARA QUE A ESTRUTURA SEJA EXECUTADA;
       
       i++; --->   A TERCEIRA PARTE REPRESENTA O INCREMENTO OU DECREMENTO DA 
       VARIÁVEL DE CONTROLE;
        
       */
        
        
        for (int i = 0; i <= 10; i++) {

        }

    }

}
