package EstruturaCondicionalSe;

public class Main {

    public static void main(String[] args) {

        /*
        
        OPERADORES LÓGICOS
        
        > MAIOR
        >= MAIOR OU IGUAL
        < MENOR
        <= MENOR OU IGUAL
        != NEGAÇÃO
        
        OPERADORES RELACIONAIS
        
        && E
        || OU
         ! NEGAÇÃO
       
        */
        
        
        int media = 7;

        if (media >= 7) {
            if (media == 10) {
                //APROVADO COM NOTA MÁXIDA
            } else {
                // APROVADO
            }
        } else {
            // REPROVADO
        }

    }
}
